import sqlite3
conn = sqlite3.connect("FForm.db")
conn.execute("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT, lname TEXT,num TEXT,gender TEXT, age TEXT, mstat TEXT, inco TEXT, estat TEXT, edu TEXT)")