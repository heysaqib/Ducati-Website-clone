from flask import*
import sqlite3

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("HomeforFlask.html")


@app.route('/FormforFlask', methods=["POST"])
def FormforFlask():
    if request.method == "POST":
        fname = request.form['fname']
        lname = request.form['lname']
        num = request.form['num']
        gender = request.form['gender']
        age = request.form['age']
        mstat = request.form['mstat']
        inco = request.form['inco']
        estat = request.form['estat']
        edu = request.form['edu']
        print(fname, lname, num, gender, age, mstat, inco, estat, edu)
        conn = sqlite3.connect("FForm.db")
        conn.execute("INSERT INTO customers(fname,lname,num,gender,age,mstat,inco,estat,edu)VALUES(?,?,?,?,?,?,?,?,?)", ( fname, lname, num, gender, age, mstat, inco, estat, edu))
        conn.commit()
        msg = "Registered successfully!"
        return render_template("FormforFlask.html", msg=msg)


@app.route('/home')
def home():
    return render_template("Assigned3(main).html")

@app.route('/formd')
def formd():
    return render_template("FormforFlask.html")

@app.route('/models')
def models():
    return render_template("Navbar-test.html")


@app.route('/contact')
def contact():
    return render_template("ContactUSforFlask.html")


@app.route('/viewme')
def viewme():
    conn = sqlite3.connect("FForm.db")
    cur = conn.execute("SELECT * FROM customers")
    rows = cur.fetchall()
    return render_template("viewme.html", rows=rows)


@app.route('/del/<a>')
def delete(a):
    conn = sqlite3.connect("FForm.db.db")
    conn.execute("DELETE FROM employees WHERE id=?", (a,))
    conn.commit()
    return redirect(url_for('viewme'))


if __name__ == "__main__":
    app.run()